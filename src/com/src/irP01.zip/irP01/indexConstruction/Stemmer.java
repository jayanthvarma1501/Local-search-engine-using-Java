package com.src.irP01.indexConstruction;

import org.tartarus.snowball.ext.PorterStemmer;

public class Stemmer {

	public String parsedContents;

	public Stemmer(String parsedContents) {
		this.parsedContents = parsedContents;
	}

	/**
	 * Method to perform stemming for words.
	 * @return stemmedContents
	 */
	public String porterStemming() {
		String stemmedContents = "";
		PorterStemmer stemmer = new PorterStemmer();

		String[] words = parsedContents.split("\\s+");

		for (String word : words) {
			stemmer.setCurrent(word);
			stemmer.stem();
			String stemmedWord = stemmer.getCurrent();
			if (stemmedContents.equalsIgnoreCase(""))
				stemmedContents = stemmedWord;
			else {
				stemmedContents += " ";
				stemmedContents += stemmedWord;
			}
		}
		return stemmedContents;
	}
}
